//
//  SimpleMath.h
//  SimpleMath
//
//  Created by Prathamesh on 27/12/23.
//

#import <Foundation/Foundation.h>

//! Project version number for SimpleMath.
FOUNDATION_EXPORT double SimpleMathVersionNumber;

//! Project version string for SimpleMath.
FOUNDATION_EXPORT const unsigned char SimpleMathVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SimpleMath/PublicHeader.h>


